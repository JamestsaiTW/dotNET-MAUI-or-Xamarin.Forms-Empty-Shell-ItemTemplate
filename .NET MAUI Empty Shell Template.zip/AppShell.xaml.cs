﻿namespace $rootnamespace$ ;

public partial class $safeitemname$ : Shell
{
    public $safeitemname$()
    {
        InitializeComponent();
    }
}

