﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFSampleApp
{
    public partial class $safeitemname$ : Xamarin.Forms.Shell
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
