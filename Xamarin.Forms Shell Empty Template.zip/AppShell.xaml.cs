﻿using Xamarin.Forms;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : Xamarin.Forms.Shell
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
